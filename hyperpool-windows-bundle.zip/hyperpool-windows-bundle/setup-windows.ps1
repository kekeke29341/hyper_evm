# =============================================================================
# Hyperpool Windows Server — WSL2 + Task Scheduler 設定スクリプト
# PowerShellで管理者権限で実行してください
# =============================================================================
# 使い方:
#   1. PowerShellを「管理者として実行」で開く
#   2. Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
#   3. .\setup-windows.ps1
# =============================================================================

param(
    [string]$WslDistro = "Ubuntu",
    [string]$InstallRoot = "/opt/hyperpool/hyper_evm",
    [string]$EnvFile = "/etc/hyperpool/env",
    [string]$LogDir = "/var/log/hyperpool"
)

$ErrorActionPreference = "Stop"

Write-Host "=== Hyperpool Windows Server セットアップ ===" -ForegroundColor Cyan
Write-Host ""

# ---- WSL2確認 ----
Write-Host "[1/4] WSL2を確認..." -ForegroundColor Yellow
$wslCheck = wsl --list --verbose 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "WSL2が見つかりません。インストールしてください:" -ForegroundColor Red
    Write-Host "  wsl --install -d Ubuntu" -ForegroundColor White
    exit 1
}
Write-Host "  WSL2: OK" -ForegroundColor Green
Write-Host $wslCheck

# ---- WSL2側でセットアップ実行 ----
Write-Host ""
Write-Host "[2/4] WSL2側でセットアップを実行..." -ForegroundColor Yellow
Write-Host "  ※ WSL2のUbuntu内でsudo setup.shが実行されます"
Write-Host ""

# zipを展開してセットアップ
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$WslScriptDir = ($ScriptDir -replace "\\", "/") -replace "^([A-Za-z]):", "/mnt/`$1".ToLower()
# Windowsドライブレターを /mnt/c 形式に変換
$WslScriptDir = $WslScriptDir -replace "^/mnt/([a-z])(.+)", { "/mnt/$($args[0].Groups[1].Value.ToLower())$($args[0].Groups[2].Value)" }

Write-Host "  Windowsパス: $ScriptDir" -ForegroundColor Gray
Write-Host "  WSL2パス:    $WslScriptDir" -ForegroundColor Gray

$setupScript = @"
set -euo pipefail
cd '$WslScriptDir'
# ファイルをコピー
sudo mkdir -p /opt/hyperpool
sudo cp -r . /opt/hyperpool/hyper_evm
sudo chown -R hyperpool:hyperpool /opt/hyperpool/hyper_evm 2>/dev/null || true
# envファイルがなければ案内
if [ ! -f /etc/hyperpool/env ]; then
  sudo install -d -m 750 /etc/hyperpool
  echo 'env.example を /etc/hyperpool/env にコピーして MAIN_PRIVATE_KEY を設定してください:'
  echo '  sudo cp /opt/hyperpool/hyper_evm/env.example /etc/hyperpool/env'
  echo '  sudo nano /etc/hyperpool/env'
fi
# セットアップ実行
if [ -f /etc/hyperpool/env ]; then
  sudo bash /opt/hyperpool/hyper_evm/setup.sh
else
  sudo bash /opt/hyperpool/hyper_evm/setup.sh || true
  echo 'env設定後にcrontabを手動で設定してください:'
  echo '  sudo bash /opt/hyperpool/hyper_evm/setup.sh'
fi
"@
wsl -d $WslDistro -- bash -c $setupScript

# ---- Windows Task Scheduler でWSL cronを自動起動 ----
Write-Host ""
Write-Host "[3/4] Windows起動時にWSL2 cronを自動起動するタスクを登録..." -ForegroundColor Yellow

$taskName = "HyperpoolWSLCron"
$taskDesc = "Windows起動時にWSL2のcronデーモンを起動する (Hyperpool cron用)"
$wslCronCmd = "wsl -d $WslDistro -- bash -c 'service cron start 2>/dev/null || crond 2>/dev/null || true'"

# 既存タスクを削除
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

$action = New-ScheduledTaskAction `
    -Execute "cmd.exe" `
    -Argument "/c `"$wslCronCmd`""

$trigger = New-ScheduledTaskTrigger -AtStartup

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 0) `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1)

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask `
    -TaskName $taskName `
    -Description $taskDesc `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal

Write-Host "  タスク '$taskName' を登録しました" -ForegroundColor Green

# ---- 今すぐcron起動 ----
Write-Host ""
Write-Host "[4/4] WSL2 cronを今すぐ起動..." -ForegroundColor Yellow
wsl -d $WslDistro -- bash -c "service cron start 2>/dev/null || crond 2>/dev/null || echo 'cron already running'"

Write-Host ""
Write-Host "=============================================="  -ForegroundColor Green
Write-Host " セットアップ完了!" -ForegroundColor Green
Write-Host "=============================================="
Write-Host ""
Write-Host "次のステップ:"
Write-Host "  1. 秘密鍵を設定 (まだの場合):"
Write-Host "     wsl -d $WslDistro -- sudo nano /etc/hyperpool/env"
Write-Host ""
Write-Host "  2. 動作確認:"
Write-Host "     wsl -d $WslDistro -- sudo -u hyperpool bash -c \"crontab -l\""
Write-Host ""
Write-Host "  3. ログ確認:"
Write-Host "     wsl -d $WslDistro -- tail -f /var/log/hyperpool/daily.log"
Write-Host "     wsl -d $WslDistro -- tail -f /var/log/hyperpool/keeper.log"
Write-Host ""
Write-Host "  4. 手動テスト (keeper):"
Write-Host "     wsl -d $WslDistro -- sudo -u hyperpool bash $InstallRoot/scripts/cron/run-keeper-vps.sh"
Write-Host ""
