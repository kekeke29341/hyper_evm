#!/usr/bin/env bash
# =============================================================================
# Hyperpool Windows Server (WSL2 Ubuntu) セットアップスクリプト
# =============================================================================
# 使い方:
#   1. このzipをWindows ServerのWSL2 Ubuntu上で /opt/hyperpool/ に展開
#   2. env.exampleをコピーして秘密鍵を設定
#        sudo install -d -m 750 /etc/hyperpool
#        sudo cp env.example /etc/hyperpool/env
#        sudo nano /etc/hyperpool/env    # MAIN_PRIVATE_KEY などを設定
#   3. このスクリプトを実行
#        sudo bash setup.sh
# =============================================================================
set -euo pipefail

INSTALL_ROOT="${HYPERPOOL_INSTALL_ROOT:-/opt/hyperpool/hyper_evm}"
ENV_FILE="${HYPERPOOL_ENV_FILE:-/etc/hyperpool/env}"
LOG_DIR="${HYPERPOOL_LOG_DIR:-/var/log/hyperpool}"

echo "=== Hyperpool WSL2 セットアップ ==="
echo "インストール先: $INSTALL_ROOT"
echo "envファイル:    $ENV_FILE"
echo "ログ:          $LOG_DIR"
echo ""

# ---- 必要パッケージ ----
echo "[1/5] Node.js 20+ をインストール..."
if ! command -v node >/dev/null 2>&1 || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 20 ]]; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq curl ca-certificates git
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y -qq nodejs
else
  echo "  Node.js $(node -v) — OK"
fi

# ---- hyperpool ユーザー ----
echo "[2/5] hyperpool ユーザーを作成..."
id hyperpool &>/dev/null || useradd -m -s /bin/bash hyperpool

# ---- ディレクトリ作成 ----
echo "[3/5] ディレクトリを作成..."
mkdir -p "$INSTALL_ROOT" "$LOG_DIR"
chown hyperpool:hyperpool "$INSTALL_ROOT" "$LOG_DIR"

# ---- ファイルをコピー ----
echo "[4/5] ファイルをコピー..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

rsync -a --exclude='.git' "$SCRIPT_DIR/" "$INSTALL_ROOT/" 2>/dev/null \
  || cp -r "$SCRIPT_DIR/." "$INSTALL_ROOT/"

chown -R hyperpool:hyperpool "$INSTALL_ROOT"

# ---- スクリプトに実行権限 ----
chmod +x "$INSTALL_ROOT"/scripts/cron/*.sh

# ---- npm ci (viem等をインストール) ----
echo "[5/5] npm ci (frontend/node_modules)..."
sudo -u hyperpool bash -c "cd '$INSTALL_ROOT/frontend' && npm ci --prefer-offline"

# ---- envファイル確認 ----
if [[ ! -f "$ENV_FILE" ]]; then
  echo ""
  echo "WARN: $ENV_FILE が見つかりません。"
  echo "  sudo install -d -m 750 /etc/hyperpool"
  echo "  sudo cp '$INSTALL_ROOT/env.example' /etc/hyperpool/env"
  echo "  sudo nano /etc/hyperpool/env   # MAIN_PRIVATE_KEY を設定"
  echo ""
fi

# ---- git設定 ----
sudo -u hyperpool git -C "$INSTALL_ROOT" config user.email \
  "${HYPERPOOL_GIT_EMAIL:-hyperpool-cron@hyperpool.local}" 2>/dev/null || true
sudo -u hyperpool git -C "$INSTALL_ROOT" config user.name \
  "${HYPERPOOL_GIT_NAME:-Hyperpool Windows Cron}" 2>/dev/null || true

# ---- crontab インストール ----
if [[ -f "$ENV_FILE" ]]; then
  echo ""
  echo "crontabをインストールします..."
  sudo -u hyperpool env \
    HYPERPOOL_ROOT="$INSTALL_ROOT" \
    HYPERPOOL_ENV_FILE="$ENV_FILE" \
    HYPERPOOL_LOG_DIR="$LOG_DIR" \
    "$INSTALL_ROOT/scripts/cron/install-vps-crontab.sh"
fi

echo ""
echo "=============================================="
echo " セットアップ完了"
echo " インストール先: $INSTALL_ROOT"
echo " ログ: $LOG_DIR/keeper.log, $LOG_DIR/daily.log"
echo ""
echo " 動作確認:"
echo "   sudo -u hyperpool env HYPERPOOL_ROOT=$INSTALL_ROOT \\"
echo "     HYPERPOOL_ENV_FILE=$ENV_FILE \\"
echo "     $INSTALL_ROOT/scripts/cron/run-keeper-vps.sh"
echo ""
echo " crontab確認:"
echo "   sudo -u hyperpool crontab -l"
echo ""
echo " ログ確認:"
echo "   tail -f $LOG_DIR/daily.log"
echo "   tail -f $LOG_DIR/keeper.log"
echo "=============================================="
