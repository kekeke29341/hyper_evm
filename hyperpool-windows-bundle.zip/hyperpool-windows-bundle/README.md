# Hyperpool Windows Server 移管パッケージ

Windows Server + WSL2 (Ubuntu) で Hyperpool の cron ジョブを動かすためのパッケージです。

## 動かすもの

| ジョブ | スケジュール (JST) | 説明 |
|--------|-------------------|------|
| Cashdrop harvest | 07:00 | オンチェーンの fee を収集 |
| Cashdrop distribute | 09:00, 09:30(リトライ) | Merkle 更新 + git push |
| Keeper rebalance | 6時間ごと | LP ポジションのリバランス |

## 前提条件

- Windows Server 2019/2022
- WSL2 + Ubuntu 22.04 または 24.04
- インターネット接続 (GitHub + RPC)
- Hyperliquid EVM の秘密鍵

---

## セットアップ手順

### 1. WSL2 の準備 (PowerShell 管理者)

```powershell
wsl --install -d Ubuntu
# 再起動後、Ubuntuユーザーを作成してから続行
```

### 2. zipを展開してセットアップ

#### 方法A: PowerShellスクリプトで自動セットアップ (推奨)

```powershell
# PowerShell を管理者として実行
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# zipを C:\hyperpool\ に展開してから:
cd C:\hyperpool\
.\setup-windows.ps1
```

#### 方法B: WSL2内で手動セットアップ

```bash
# WSL2 Ubuntu内で実行
# zipを /tmp/hyperpool-bundle/ に展開済みとする
sudo mkdir -p /etc/hyperpool
sudo cp /tmp/hyperpool-bundle/env.example /etc/hyperpool/env
sudo nano /etc/hyperpool/env   # MAIN_PRIVATE_KEY を入力

sudo bash /tmp/hyperpool-bundle/setup.sh
```

### 3. 秘密鍵を設定

```bash
# WSL2 Ubuntu内
sudo nano /etc/hyperpool/env
```

以下の値を必ず設定:

```bash
MAIN_PRIVATE_KEY=0xYOUR_PRIVATE_KEY
DEPLOYMENT_CHAIN=999
```

### 4. 動作確認

```bash
# WSL2内でkeeperを手動実行
sudo -u hyperpool env \
  HYPERPOOL_ROOT=/opt/hyperpool/hyper_evm \
  HYPERPOOL_ENV_FILE=/etc/hyperpool/env \
  /opt/hyperpool/hyper_evm/scripts/cron/run-keeper-vps.sh

# crontab確認
sudo -u hyperpool crontab -l
```

### 5. Windows 起動時の自動起動

`setup-windows.ps1` が Windows Task Scheduler に `HyperpoolWSLCron` タスクを登録します。
これにより Windows Server 再起動後も WSL2 の cron が自動起動します。

---

## ファイル構成

```
hyperpool-windows-bundle/
├── README.md                    # このファイル
├── setup.sh                     # WSL2内セットアップスクリプト
├── setup-windows.ps1            # Windows PowerShellセットアップ
├── env.example                  # 環境変数テンプレート
├── scripts/
│   ├── daily-rewards.mjs        # Cashdrop harvest/distribute
│   ├── keeper-rebalance.mjs     # Keeper rebalance
│   ├── lib/                     # 共有ライブラリ
│   └── cron/                    # cronラッパースクリプト
├── frontend/
│   ├── package.json             # npm ci用 (viem等)
│   ├── package-lock.json
│   └── src/lib/contracts/
│       ├── abis/                # コントラクトABI
│       └── deployments/         # デプロイアドレス (999.json等)
└── contracts/
    └── deployments/             # 同上 (scripts参照用)
```

## 詳細手順書（Cursor 操作含む）

Cursor から WSL2 に接続してセットアップする全手順は、リポジトリの  
`docs/本番運用/windows-server-wsl2-cron.md` を参照してください。  
（zip に入れていないため、GitHub またはリポジトリクローン後にご確認ください）

---

## トラブルシューティング

### npm ciが失敗する

```bash
cd /opt/hyperpool/hyper_evm/frontend
npm ci
```

### git pushが失敗する

Merkle 更新後に git push で GitHub に反映します。
push するにはリポジトリへの書き込み権限が必要です。

```bash
# SSHキーを設定するか、HTTPSのPersonal Access Tokenを使用:
# /etc/hyperpool/env に追記:
# GIT_REMOTE_URL=https://YOUR_TOKEN@github.com/kekeke29341/hyper_evm.git
```

または /opt/hyperpool/hyper_evm でリモートURLを変更:
```bash
sudo -u hyperpool git -C /opt/hyperpool/hyper_evm remote set-url origin https://TOKEN@github.com/kekeke29341/hyper_evm.git
```

### ログの確認

```bash
# WSL2内
tail -100 /var/log/hyperpool/daily.log
tail -100 /var/log/hyperpool/keeper.log
```
